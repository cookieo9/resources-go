package resources

import (
	. "testing"
)

func TestZip(t *T) {
	path := "foo.zip"
	pattern := "*_test.go"

	t.Log("Opening", path)
	zb, err := ZipOpen(path)
	if err != nil {
		t.Fatal(err)
	}
	defer zb.(Closer).Close()

	files, err := zb.Glob(pattern)
	if err != nil {
		t.Fatal(err)
	}
	t.Logf("Glob(%s): %+v", pattern, files)
}
